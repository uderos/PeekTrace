#include "stdafx.h"
#include "Config.h"
#include "Filter.h"


Filter::Filter()
{
	m_setup_filters();
}


Filter::~Filter()
{
}

bool Filter::test_string(const std::string & str) const
{
	bool and_test_result = true;
	for (const auto & re_ptr : m_and_filters)
	{
		std::smatch m;
		and_test_result = and_test_result && std::regex_match(str, m, *re_ptr);
	}

	bool or_test_result = false;
	if (and_test_result)
	{
		for (const auto & re_ptr : m_or_filters)
		{
			std::smatch m;
			or_test_result = or_test_result || and_test_result && std::regex_match(str, m, *re_ptr);
		}
	}

	const bool test_result = and_test_result && or_test_result;

	return test_result;
}

Filter::regex_ptr Filter::m_create_regex(const std::string & user_filter_str) const
{
	std::ostringstream oss;
	oss << "^.*" << user_filter_str << ".*";
	return std::make_unique<std::regex>(oss.str());
}


void Filter::m_setup_filters()
{
	std::vector<std::string> and_filter_str, or_filter_str;
	g_CONFIG.GetFilters(and_filter_str, or_filter_str);

	for (const std::string str_filter : and_filter_str)
		m_and_filters.emplace_back(m_create_regex(str_filter));

	for (const std::string str_filter : or_filter_str)
		m_or_filters.emplace_back(m_create_regex(str_filter));
}

