#pragma once
class Filter
{
public:
	Filter();
	virtual ~Filter();
	bool test_string(const std::string & str) const;

private:
	
};

