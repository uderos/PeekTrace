#include "stdafx.h"
#include "Config.h"
#include "Filter.h"


Filter::Filter()
{
}


Filter::~Filter()
{
}

bool Filter::test_string(const std::string & str) const
{
	return true; // TODO
}

