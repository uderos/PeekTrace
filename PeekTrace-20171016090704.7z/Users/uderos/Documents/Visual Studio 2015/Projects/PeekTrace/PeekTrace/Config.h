#pragma once

#define g_CONFIG (Config::Instance())

class Config
{
	public:

		static Config & Instance();

		void ProcessCmdLine(const int argc, const char *argv[]);
		void Dump() const;

		const fs::path & GetInpoutFilePath() const;
		bool GetVerboseFlag() const;
		bool GetTailFlag() const;
		void GetFilters(
			std::vector<std::string> & and_filters,
			std::vector<std::string> & or_filters);

	private:

		static Config * m_instance_ptr;

		bool m_has_configuration;
		bool m_verbose_flag;
		bool m_tail_flag;
		std::vector<std::string> m_and_filters;
		std::vector<std::string> m_or_filters;

		fs::path m_input_file_path;

		Config();
		virtual ~Config();

};

