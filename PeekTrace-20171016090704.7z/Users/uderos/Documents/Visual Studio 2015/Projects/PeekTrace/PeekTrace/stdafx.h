// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

//#include <stdio.h>
//#include <tchar.h>

#include <cctype>
#include <codecvt>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <locale>
#include <memory>
#include <regex>
#include <stdexcept>
#include <string>
#include <sstream>
#include <thread>

#include "boost/filesystem.hpp"
#include "boost/program_options.hpp"

namespace fs = boost::filesystem;





// TODO: reference additional headers your program requires here
