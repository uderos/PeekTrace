#pragma once
class Executor
{
public:
	Executor(const int argc, const char *argv[]);
	virtual ~Executor();

	bool Run();
};

